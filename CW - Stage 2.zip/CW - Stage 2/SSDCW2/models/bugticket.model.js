//dependency
const mongoose = require('mongoose');

//data inputted into the database
var bugticketSchema = new mongoose.Schema({
    ticketNumber: {
        type: Number,
        required: 'This field is required.'
    },
    type: {
        type: String
    },
    priority: {
        type: String
    },
    date: {
        type: String
    },
    time: {
        type: String
    },
    description: {
        type: String
    },
    ticketUsername: {
        type: String
    },
    assignedDeveloper: {
        type: String
    },
    status: {
        type: String
    }
});

mongoose.model('BugTicket', bugticketSchema);