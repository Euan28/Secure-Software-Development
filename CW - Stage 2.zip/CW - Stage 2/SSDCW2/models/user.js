//dependencies 
var mongoose = require('mongoose');
var bcrypt = require('bcrypt');

//data inputted into the database, validations, for a new user when registering
var UserSchema = new mongoose.Schema({
    username: {
        type: String,
        unique: true,
        required: true,
        trim: true
    },
    password: {
        type: String,
        required: true,
    }
});

//authenticate input against database, return the user if found, if there is not user then an error message will be displayed, if all is good
//bcrypt module will be used to compare the password before hashing it in the next function
UserSchema.statics.authenticate = function(username, password, callback) {
    User.findOne({
            username: username
        })
        .exec(function(err, user) {
            if (err) {
                return callback(err)
            } else if (!user) {
                var err = new Error('User not found.');
                err.status = 401;
                return callback(err);
            }
            bcrypt.compare(password, user.password, function(err, result) {
                if (result === true) {
                    return callback(null, user);
                } else {
                    return callback();
                }
            })
        });
}

//hashing and salting a password before saving it to the database
UserSchema.pre('save', function(next) {
    var salt = 10;
    var user = this;
    bcrypt.hash(user.password, salt, function(err, hash) {
        if (err) {
            return next(err);
        }
        // set hashed password
        user.password = hash;
        next();
    })
});

var User = mongoose.model('User', UserSchema);
module.exports = User;