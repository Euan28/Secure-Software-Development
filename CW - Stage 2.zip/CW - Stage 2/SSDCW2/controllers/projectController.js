//dependencies and it requires a file in the models folder, user.js
const express = require('express');
var router = express.Router();
const mongoose = require('mongoose');
const BugTicket = mongoose.model('BugTicket');
var User = require('../models/user');
var passport = require('passport'); // authentication middleware for Node.js
var localStrategy = require('passport-local').Strategy; // passport strategy for authenticating with a username and password

//router.get (GET request) and res.render (compiles your template) is used to get the directories 
//and send the user to the page they which to be sent too, also validation like layout to choose the specific layout
//renders the addOrEdit.hbs page
router.get('/addOrEdit', (req, res) => {
    res.render("addOrEdit", {
        viewTitle: "Add Ticket"
    });
});

//renders the home.hbs page
router.get('/home', (req, res) => {
    res.render('home', {
        layout: 'main.hbs'
    });
});

//renders the login.hbs page
router.get('/login', (req, res) => {
    res.render('login', {
        layout: 'main.hbs'
    });
});

//renders the comment.hbs page
router.get('/comment', (req, res) => {
    res.render('comment', {
        layout: 'main.hbs'
    });
});

//renders the comment.hbs page
router.get('/test', (req, res) => {
    res.render('test', {
        layout: 'main.hbs'
    });
});

//renders the register.hbs page 
router.get('/register', (req, res) => {
    res.render('register', {
        layout: 'main.hbs'
    });
});

//login and registration section - use of login.hbs and register.hbs

//POST route for updating data
router.post('/login', function(req, res, next) {
    // confirm that user typed same password twice, if not it will inform the user
    if (req.body.password !== req.body.passwordConf) {
        var err = new Error('Passwords do not match.');
        err.status = 400;
        res.send("Passwords do not match, please try again!");
        res.render('register');
        return next(err);
    }
    //the data inputted is inserted into the database, everything but the confirmed password
    if (req.body.username &&
        req.body.password &&
        req.body.passwordConf) {

        var userData = new User ({
            username: req.body.username,
            password: req.body.password,
        })
        //creating a new user, if the user already exists the application with inform the user, otherwise, it will render the home.hbs page
        User.create(userData, function(error, user) {
            if (error) {
                res.send('Sorry, a user already exists with these details, please try again!');
            } else {
                return res.render('home');
            }
        });
    //authenticatication for the user when logging in, if the either the email or password is incorrect, then the user will be informed of the wrong
    //combination, otherwise it will render the home.hbs page
    } else if (req.body.username && req.body.logpassword) {
        User.authenticate(req.body.username, req.body.logpassword, function(error, user) {
            if (error || !user) {
                res.send('Sorry, you have used the wrong combination of username and password, please try again!');
            } else {
                return res.render('home');
            }
        });
    //validation to ensure that all input fields have been used, if not, the error message will appear to the user
    } else {
        var err = new Error('All fields required.');
        err.status = 400;
        return next(err);
    }
})

//GET reuqest for logout, if the user logs out, it will render the login.hbs page
router.get('/logout', function(req, res, next) {
    if (req.session) {
        // delete session object
        req.session.destroy(function(err) {
            if (err) {
                return next(err);
            } else {
                return res.render('login');
            }
        });
    }
});

// members page
router.get('/', ensureAuthenticated, function(req, res, next) {
	res.render('home', {
		title: 'Home'
	});
});

function ensureAuthenticated(req, res, next) {
	if (req.isAuthenticated()) {
		return next();
	}
	req.flash('error', 'You have to Login First.'); // if user is not authenticated, the server will send the user to the home page
	res.redirect('/SSDCW2/login');
}

// flow (IV) [passport creating a session for current logged in user by serialising it.]
passport.serializeUser(function(user, done) {
	done(null, user[0].id);
});

// deserialiing user 
passport.deserializeUser(function(id, done) {
	User.findById(id, function(err, user) {
		done(err, user);
	});
});

// flow (III)
var comparePassword = function(candidatePassword, hash, callback) {
	bcrypt.compare(candidatePassword, hash, function(err, isMatch) {
		if (err) return callback(err);
		callback(null, isMatch);
	});
}

// flow (II)
passport.use(new localStrategy(function(username, password, done) {
	User.find({
		username: username
	}, function(err, user) {
		if (err) throw err;
		if (user.length == 0) {
			console.log('Unknown User');
			return done(null, false, {
				message: 'Unknown User'
			});
		}
		comparePassword(password, user[0].password, function(err, isMatch) {
			if (err) throw err;
			if (isMatch) {
				return done(null, user);
				res.redirect('/SSDCW2/home');
			} else {
				console.log('Invalid Password');
				return done(null, false, {
					message: 'Invalid Password'
				});
			}
		})
	});
}));

//flow (I)
router.post('/login', passport.authenticate('local', {
	failureRedirect: '/SSDCW2/login',
	failureFlash: 'Invalid Username or Password'
}), function(req, res) {
	// if local strategy comes true
	console.log('Authentication Successful');
	req.flash('success', 'You are Logged In');
	res.redirect('/SSDCW2/home');
});

// logging out
router.get('/logout', function(req, res) {
	req.logout();
	req.flash('success', 'You have logged out');
	res.redirect('/SSDCW2/login');
});

//bugticket page section - addOrEdit.hbs and list.hbs

//checks comparison of two values to either insert new data - runs the insertRecord function - or updates the data - runs the updateRecord function
router.post('/addOrEdit', (req, res) => {
    if (req.body._id == '')
        insertRecord(req, res);
    else
        updateRecord(req, res);
});

//inserting data considering the bug ticket etc including validation, if there is no error with the inputted validation, the user will 
//be redirected to the list.hbs page, else if the error is a validation error, it will render the addOrEdit.hbs page and else will state to the
//user that there was an error with inserting a new record of data followed by the type of error
function insertRecord(req, res) {
    var bugticket = new BugTicket();
    bugticket.ticketNumber = req.body.ticketNumber;
    bugticket.type = req.body.type;
    bugticket.priority = req.body.priority;
    bugticket.date = req.body.date;
    bugticket.time = req.body.time;
    bugticket.description = req.body.description;
    bugticket.ticketUsername = req.body.ticketUsername;
    bugticket.assignedDeveloper = req.body.assignedDeveloper;
    bugticket.status = req.body.status;
    bugticket.save((err, doc) => {
        if (!err)
            res.redirect('/SSDCW2/list');
        else {
            if (err.name == 'ValidationError') {
                handleValidationError(err, req.body);
                res.render("addOrEdit", {
                    viewTitle: "Insert Ticket",
                    bugticket: req.body
                });
            } else
                console.log('Error during record insertion : ' + err);
        }
    });
}

//function to allow users to be able to edit their list of bug tickets etc, if there is no errors, the user will be redirected to the list.hbs page
//however, if there is an error that is a validation error, it will render the addOrEdit.hbs page and else will state to the
//user that there was an error with inserting a new record of data followed by the type of error
function updateRecord(req, res) {
    BugTicket.findOneAndUpdate({
        _id: req.body._id
    }, req.body, {
        new: true
    }, (err, doc) => {
        if (!err) {
            res.redirect('/SSDCW2/list');
        } else {
            if (err.name == 'ValidationError') {
                handleValidationError(err, req.body);
                res.render("addOrEdit", {
                    viewTitle: 'Update Module',
                    bugticket: req.body
                });
            } else
                console.log('Error during record update : ' + err);
        }
    });
}

//get request to get the list.hbs page rendered if there is no error, else it will display the message in the console log that there was trouble
//in retrieving the module list
router.get('/list', (req, res) => {
    BugTicket.find((err, docs) => {
        if (!err) {
            res.render("list", {
                list: docs
            });
        } else {
            console.log('Error in retrieving bug ticket list :' + err);
        }
    });
});

//finding the inserted data by id and rendering the addOrEdit.hbs page with updated data
router.get('/:id', (req, res) => {
    BugTicket.findById(req.params.id, (err, doc) => {
        if (!err) {
            res.render("addOrEdit", {
                viewTitle: "Update Ticket",
                bugticket: doc
            });
        }
    });
});

//note the public folder for further details
module.exports = {
    router
}